/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author sandile
 */
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class LeagueTableTest {

    private LeagueTable leagueTable;

    @BeforeEach
    public void setUp() {
        leagueTable = new LeagueTable();
    }

    @Test
    public void testSingleGame() {
        leagueTable.addGameResult("Lions 3, Snakes 1");
        List<String> ranking = leagueTable.getRanking();
        assertEquals(List.of("1. Lions, 3 pts", "2. Snakes, 0 pts"), ranking);
    }

    @Test
    public void testDrawGame() {
        leagueTable.addGameResult("Lions 2, Snakes 2");
        List<String> ranking = leagueTable.getRanking();
        assertEquals(List.of("1. Lions, 1 pt", "1. Snakes, 1 pt"), ranking);
    }

    @Test
    public void testMultipleGames() {
        leagueTable.addGameResult("Lions 3, Snakes 1");
        leagueTable.addGameResult("Tarantulas 1, FC Awesome 0");
        leagueTable.addGameResult("Lions 1, FC Awesome 1");
        leagueTable.addGameResult("Tarantulas 3, Snakes 1");
        leagueTable.addGameResult("Lions 4, Grouches 0");

        List<String> ranking = leagueTable.getRanking();
        assertEquals(List.of(
                "1. Lions, 7 pts",
                "2. Tarantulas, 6 pts",
                "3. FC Awesome, 1 pt",
                "4. Grouches, 0 pts",
                "5. Snakes, 0 pts"
        ), ranking);
    }

    @Test
    public void testEmptyInput() {
        List<String> ranking = leagueTable.getRanking();
        assertEquals(List.of(), ranking);
    }
}


